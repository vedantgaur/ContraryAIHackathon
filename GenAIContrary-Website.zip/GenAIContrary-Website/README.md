# cognate.ai

Run Instructions: 
```
streamlit run mainpage.py
```
